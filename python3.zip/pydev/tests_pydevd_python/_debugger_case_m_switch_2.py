class ClassToBeImported(object):
    pass