from isort.main import main

main()
